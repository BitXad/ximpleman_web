<!----------------------------- script buscador --------------------------------------->
<script src="<?php echo base_url('resources/js/jquery-2.2.3.min.js'); ?>" type="text/javascript"></script>
<script type="text/javascript">
        $(document).ready(function () {
            (function ($) {
                $('#filtrar').keyup(function () {
                    var rex = new RegExp($(this).val(), 'i');
                    $('.buscar tr').hide();
                    $('.buscar tr').filter(function () {
                        return rex.test($(this).text());
                    }).show();
                })
            }(jQuery));
        });
</script>   
<!----------------------------- fin script buscador --------------------------------------->
<!------------------ ESTILO DE LAS TABLAS ----------------->
<link href="<?php echo base_url('resources/css/mitabla.css'); ?>" rel="stylesheet">
<!-------------------------------------------------------->
<div class="box-header">
    <h3 class="box-title"><b>Servicios</b></h3><br>
    <div class="container">  
        <div class="box-tools">
            
                <a class="btn btn-success btn-foursquarexs" href="<?php echo site_url('servicio/crearservicio'); ?>"><font size="5"><span class="fa fa-plus-circle"></span></font><br><small>Nuevo Servicio</small></a>
                <a class="btn btn-warning btn-foursquarexs" data-toggle="modal" data-target="#modalbuscar" ><font size="5"><span class="fa fa-search"></span></font><br><small>Codigo Servicio</small></a>
                
            
        </div>
        <div class="panel panel-footer col-md-5">
            <table class="table table-striped table-condensed">
                <tr>
                    <td><b>Buscar por Estado de Producto</b></td>
                    <td></td>
                    <td><b>Buscar por Categoria Servicio</b></td>
                    <td></td>
                </tr>
                <tr>
                    <?php echo form_open('detalle_serv/buscarporestado'); ?>
                    <td>
                        <select name="estado_id" class="form-control" id="estado_id">
                            <option value="">- ESTADO -</option>
                            <?php
                            foreach($all_estado as $estado)
                            {
                                    echo '<option value="'.$estado['estado_id'].'">'.$estado['estado_descripcion'].'</option>';
                            } 
                            ?>
                        </select>
                    </td>
                    <td>
                        <button type="submit" class="btn btn-warning btn-xs">
                            <i class="fa fa-search"></i>
                        </button>
                    </td>
                    <?php echo form_close(); ?>
                    <?php /* echo form_open('detalle_serv/buscarportrabajo'); ?>
                    <td>
                        <select name="cattrab_id" class="form-control" id="cattrab_id">
                        <option value="">- TIPO TRABAJO -</option>
                        <?php
                        foreach($all_categoria_trabajo as $cat_trabajo)
                        {
                                echo '<option value="'.$cat_trabajo['cattrab_id'].'">'.$cat_trabajo['cattrab_descripcion'].'</option>';
                        } 
                        ?>
                        </select>
                    </td>
                    <td>
                       <button type="submit" class="btn btn-warning btn-xs">
                        <i class="fa fa-search"></i>
                </button> 
                    </td>
                    <?php echo form_close();*/ ?>
                    <?php echo form_close(); ?>
                    <?php echo form_open('detalle_serv/buscarporcatserv'); ?>
                    <td>
                        <select name="catserv_id" class="form-control" id="catserv_id">
                        <option value="0">- SERVICIO -</option>
                        <?php
                        foreach($all_categoria_servicio as $catserv)
                        {
                            if($catserv['catserv_id'] <>0){
                                echo '<option value="'.$catserv['catserv_id'].'">'.$catserv['catserv_descripcion'].'</option>';
                            }
                        } 
                        ?>
                        </select>
                    </td>
                    <td>
                       <button type="submit" class="btn btn-warning btn-xs">
                        <i class="fa fa-search"></i>
                </button> 
                    </td>
                    <?php echo form_close(); ?>
                </tr>
                
            </table>

        </div>
        
    </div>
</div>

<div class="row">
    <div class="col-md-12">
        <!--------------------- parametro de buscador --------------------->
                  <div class="input-group"> <span class="input-group-addon">Buscar</span>
                    <input id="filtrar" type="text" class="form-control" placeholder="Ingrese el cliente, fecha recepción, estado del servicio">
                  </div>
            <!--------------------- fin parametro de buscador --------------------->
        <div class="box">
            
            <div class="box-body table-responsive">
                <table class="table table-striped table-condensed" id="mitabla">
                    <tr>
						<th>Num.</th>
                                                <th>Cliente</th>
                                                <th>Codigo</th>
                                                <th>Fechas</th>
						<th>Estado</th>
						<th>Tipo Servicio</th>
						
						<th>Registrado por </th>
						
						<th>Total</th>
						<th>Acuenta</th>
						<th>Saldo</th>
						<th></th>
                    </tr>
                    <tbody class="buscar">
                    <?php $i =1; $cont = 0; foreach($servicio as $s){ $cont = $cont+1; ?>
                    <tr>
                        <td><?php echo $cont ?></td>
                        <td><?php echo $s['cliente_nombre']; ?></td>
                        <td><?php echo $s['servicio_id']; ?></td>
                        <td><?php $fechamos = "";
                                if($s['servicio_fechafinalizacion'] <> null) $fechamos = date('d/m/Y', strtotime($s['servicio_fechafinalizacion']));
                                echo "<font size='1'><b>Recep.: </b>".date('d/m/Y', strtotime($s['servicio_fecharecepcion'])).'|'.$s['servicio_horarecepcion']."<br>";
                                echo "<b>Salida: </b>".$fechamos.'|'.$s['servicio_horafinalizacion']."</font>";
                        ?></td>
                        <td style="background-color: #<?php echo $s['estado_color']; ?>"><?php echo $s['estado_descripcion']; ?></td>
                        <td><?php //Tipo de Servicio 1 esta definido como "Servicio Normal"
                            echo $s['tiposerv_descripcion']."<br>";
                            if($s['tiposerv_id'] <> 1){
                                echo "<font size='1'><b>Dir.: </b>".$s['servicio_direccion']."</font>";
                            }
                         ?></td>

                        <td><?php echo $s['usuario_nombre']; ?></td>

                        <td><?php echo $s['servicio_total']; ?></td>
                        <td><?php echo $s['servicio_acuenta']; ?></td>
                        <td><?php echo $s['servicio_saldo']; ?></td>
                        <td>
                                                    
                                  <!------------------------ INICIO modal para confirmar Anulacion ------------------->
                                    <div class="modal fade" id="modalanulado<?php echo $i; ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel<?php echo $i; ?>">
                                      <div class="modal-dialog" role="document">
                                            <br><br>
                                        <div class="modal-content">
                                          <div class="modal-header">
                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">x</span></button>
                                          </div>
                                          <div class="modal-body">
                                           <!------------------------------------------------------------------->
                                           <h3>
                                               ¿Desea Anular el Servicio <b> <?php echo $s['servicio_id']; ?></b>?
                                           </h3>
                                           Al ANULAR este servicio, se anularan todos sus detalles(incluidos Total, A cuenta y Saldo seran CERO).
                                           <!------------------------------------------------------------------->
                                          </div>
                                          <div class="modal-footer aligncenter">
                                                      <a href="<?php echo site_url('servicio/anularserv/'.$s['servicio_id']); ?>" class="btn btn-danger"><span class="fa fa-pencil"></span> Si </a>
                                                      <a href="#" class="btn btn-success" data-dismiss="modal"><span class="fa fa-times"></span> No </a>
                                          </div>
                                        </div>
                                      </div>
                                    </div>
                        <!------------------------ FIN modal para confirmar Anulacion ------------------->
                                                    
                            <a href="<?php echo site_url('servicio/serview/'.$s['servicio_id']); ?>" class="btn btn-info btn-xs"><span class="fa fa-pencil"></span></a> 
                            <a data-toggle="modal" data-target="#modalanulado<?php echo $i; ?>" class="btn btn-warning btn-xs"><span class="fa fa-minus-circle"></span></a>
                            <a href="<?php echo site_url('servicio/remove/'.$s['servicio_id']); ?>" class="btn btn-danger btn-xs"><span class="fa fa-trash"></span></a>
                        </td>
                    </tr>
                    <?php $i++; } ?>
                </table>
                                
            </div>
        </div>
    </div>
</div>
<?php
    if(isset($a)){ ?>
        <script type="text/javascript">
        alert('No Existe ese servicio')
</script> 
<?php
    }
    ?>

<!-- ---------------------- Inicio modal para Buscar un servicio por su codigo (servicio_id) ----------------- -->
                                    <div class="modal fade" id="modalbuscar" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                                      <div class="modal-dialog" role="document">
                                            <br><br>
                                        <div class="modal-content">
                                          <div class="modal-header">
                                              <label>Buscar por Codigo:</label>
                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">x</span></button>
                                          </div>
                                            <?php
                                            echo form_open('servicio/buscarporcod');
                                            ?>
                                          <div class="modal-body">
                                           <!------------------------------------------------------------------->
                                           
                                           <div class="col-md-6">
						<label for="servicio_id" class="control-label"><span class="text-danger">*</span>Codigo</label>
						<div class="form-group">
							<input type="text" name="servicio_id" class="form-control" id="cliente_nombre" required />
						</div>
					  </div>
                                           <!------------------------------------------------------------------->
                                          </div>
                                          <div class="modal-footer aligncenter">
                                              <button type="submit" class="btn btn-warning">
                                                    <i class="fa fa-search"></i> Buscar
                                              </button>
<!--                                              <a href="<?php // echo site_url('cliente/add_new'); ?>" type="submit" class="btn btn-success">
                                                <i class="fa fa-check"></i> Guardar
                                              </a>-->
                                              <a href="#" class="btn btn-danger" data-dismiss="modal">
                                                    <i class="fa fa-times"></i> Cancelar</a>
                                          </div>
                                            <?php echo form_close(); ?>
                                        </div>
                                      </div>
                                    </div>
<!-- ---------------------- Fin modal para Buscar un servicio por su codigo (servicio_id) ----------------- -->
            