<style>@page {
                margin-top: 2cm;
                margin-bottom: 2cm;
                margin-left: 2cm;
                margin-right: 2cm;

            }
            body {
                text-align: left;
        }
       hr {
  height: 3px;
  color: black;
  margin:0% 0% 3% 0%;
}
.box1 {
width:100%;
margin:0% 10%;
padding:10px;
align: right;
border:3px solid black;
border-bottom: 0px;
border-right: 0px;
}
.box2 {

margin:5% 15%;
padding:10px;
border:3px solid black;
}

.box3 {
width:100%;
margin:3% 0% 0% 0%;
padding:1px;
border:3px solid black;
}
.box4 {
width:100%;
margin:0% 0% 0% 0%;
padding-top:60px;
border:3px solid black;
border-top: 0px;
}


    .box {
        overflow: hidden;
    }

    .content {
        font-size: 15px;
        line-height: 20px;
        padding: 0 20px;
        text-align: justify;
    }

    .left {
        float: left;
        width: 50%;
    }

    .left .content {
        border-right: 5px solid #4BB495  ;
    }

    .right {
        float: right;
        width: 50%;
    }

     .left1 {
        float: left;
        width: 25%;
    }
     .medio1 {
        float: left;
        width: 35%;
    }
       .right1 {
        float: right;
        width: 40%;
    }

         </style>
        <div class="box"> 
        <div class="left1">   
 <td><img src="/ximpleman_web/resources/images/logos.png";  style="width:100px;height:100px"> </td></div>
 <div class="medio1" align="center">       <h2 align="center"><b>BURGER KING</b></h2>

 Av. Ballivivian #666 <br>
 Telf: 666666-7777777 <br>
 COCHABAMBA-BOLIVIA</div>
     <div class="right1">        <div class="box1" ><h2><b>Recibo de egreso</b></h2>
             Numero: <b>'.$egresos['egreso_id'].'</b>  <br>
             Numero transaccion: <b>'.$egresos['egreso_numero'].'</b>  </div>  </div>
<hr>
            </div>       
           <div class="box">
                       <div class="left">
                <div class="content">Fecha y Hora: 
                            <b>'.$egresos['egreso_fecha'].'</b>            
                 </div>
            </div>
            <div class="right">
                <div class="content">Apellidos y Nombre(s): <b>'.$egresos['egreso_nombre'].'</b>  </div>
            </div>
        </div>
      
                            
 <div class="box3">            

              <div class="box2">                        
                        
                        <th>MONTO:  </th>
                            
                            <td>'.$egresos['egreso_monto'].''.$egresos['egreso_moneda'].'</td>                      
    </div>

              <div class="box2">
                        <th>CONCEPTO:    </th>
                             <td>'.$egresos['egreso_categoria'].'</td>
                             <td>('.$egresos['egreso_concepto'].')</td>


              </div> 

              <div class="box2">
                        <th>SON:    </th>
                             <td> '.$egresos['egreso_monto'].' </td>
                

              </div> 

           
             <div class="box2">          
            <th>CAJERO:  </th>
            <td>'.$usu['usuario_nombre'].'</td>
             </div>
</div>

 <div class="box4">            


              <div class="box">
            <div class="left">
                <div class="content" align="center">
                <hr>
                    Firma interesado.
                </div>
            </div>
            <div class="right">
                <div class="content" align="center">
                <hr>
                    Firma cajero.
                </div>
            </div>
        </div>

</div>