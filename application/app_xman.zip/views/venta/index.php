<!----------------------------- script buscador --------------------------------------->
<script src="<?php echo base_url('resources/js/jquery-2.2.3.min.js'); ?>" type="text/javascript"></script>
<script type="text/javascript">
        $(document).ready(function () {
            (function ($) {
                $('#filtrar').keyup(function () {
                    var rex = new RegExp($(this).val(), 'i');
                    $('.buscar tr').hide();
                    $('.buscar tr').filter(function () {
                        return rex.test($(this).text());
                    }).show();
                })
            }(jQuery));
        });
</script>   
<!----------------------------- fin script buscador --------------------------------------->
<!------------------ ESTILO DE LAS TABLAS ----------------->
<link href="<?php echo base_url('resources/css/mitabla.css'); ?>" rel="stylesheet">
<!-------------------------------------------------------->
<div class="box-header">
                <h3 class="box-title">Ventas</h3>
            	<div class="box-tools">
                    <a href="<?php echo site_url('venta/add'); ?>" class="btn btn-success btn-sm">+ Añadir</a> 
                </div>
</div>
<div class="row">
    <div class="col-md-12">
        <!--------------------- parametro de buscador --------------------->
                  <div class="input-group"> <span class="input-group-addon">Buscar</span>
                    <input id="filtrar" type="text" class="form-control" placeholder="Ingrese usuario, cliente, fecha">
                  </div>
            <!--------------------- fin parametro de buscador --------------------->
        <div class="box">
            
            <div class="box-body table-responsive">
                <table class="table table-striped table-condensed" id="mitabla">
                    <tr>
						<th>Num.</th>
						<th>N°&nbsp;de<br>Transacción</th>
						<th>Forma</th>
						<th>Tipo<br>Trans.</th>
						<th>Usuario</th>
						<th>Cliente</th>
						<th>Fecha</th>
						<th>Hora</th>
						<th>Subtotal</th>
						<th>Descuento</th>
						<th>Total</th>
						<th>Efectivo</th>
						<th>Cambio</th>
						<th>Moneda</th>
						<th>Glosa</th>
						<th>Comisión</th>
						<th>Tipo<br>Cambio</th>
						<th>Estado</th>
						<th>Operaciones</th>
                    </tr>
                    <tbody class="buscar">
                    <?php $cont = 0;
                          foreach($venta as $v){;
                                 $cont = $cont+1; ?>
                    <tr>
						<td><?php echo $cont ?></td>
						<td><?php echo $v['venta_id']; ?></td>
						<td><?php echo $v['forma_nombre']; ?></td>
						<td><?php echo $v['tipotrans_nombre']; ?></td>
						<td><?php echo $v['usuario_nombre']; ?></td>
						<td><?php echo $v['cliente_nombre']; ?></td>
						<td><?php echo $v['venta_fecha']; ?></td>
						<td><?php echo $v['venta_hora']; ?></td>
						<td><?php echo $v['venta_subtotal']; ?></td>
						<td><?php echo $v['venta_descuento']; ?></td>
						<td><?php echo $v['venta_total']; ?></td>
						<td><?php echo $v['venta_efectivo']; ?></td>
						<td><?php echo $v['venta_cambio']; ?></td>
						<td><?php echo $v['moneda_descripcion']; ?></td>
						<td><?php echo $v['venta_glosa']; ?></td>
						<td><?php echo $v['venta_comision']; ?></td>
						<td><?php echo $v['venta_tipocambio']; ?></td>
						<td><?php echo $v['estado_descripcion']; ?></td>
						<td>
                            <a href="<?php echo site_url('venta/edit/'.$v['venta_id']); ?>" class="btn btn-info btn-xs"><span class="fa fa-pencil"></span></a> 
                            <a href="<?php echo site_url('venta/remove/'.$v['venta_id']); ?>" class="btn btn-danger btn-xs"><span class="fa fa-trash"></span></a>
                        </td>
                    </tr>
                    <?php } ?>
                </table>
                <div class="pull-right">
                    <?php echo $this->pagination->create_links(); ?>                    
                </div>                
            </div>
        </div>
    </div>
</div>
