<?php

echo $web;