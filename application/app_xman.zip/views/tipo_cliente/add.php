<div class="row">
    <div class="col-md-12">
      	<div class="box box-info">
            <div class="box-header with-border">
              	<h3 class="box-title">Añadir Tipo Cliente</h3>
            </div>
            <?php echo form_open('tipo_cliente/add'); ?>
          	<div class="box-body">
          		<div class="row clearfix">
					<div class="col-md-6">
						<label for="tipocliente_descripcion" class="control-label"><span class="text-danger">*</span>Descripción</label>
						<div class="form-group">
							<input type="text" name="tipocliente_descripcion" value="<?php echo $this->input->post('tipocliente_descripcion'); ?>" class="form-control" id="tipocliente_descripcion" required />
							<span class="text-danger"><?php echo form_error('tipocliente_descripcion');?></span>
						</div>
					</div>
					<div class="col-md-6">
						<label for="tipocliente_porcdesc" class="control-label">Porc. Desc.</label>
						<div class="form-group">
							<input type="number" name="tipocliente_porcdesc" value="<?php echo $this->input->post('tipocliente_porcdesc'); ?>" class="form-control" id="tipocliente_porcdesc" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="tipocliente_montodesc" class="control-label">Monto Desc.</label>
						<div class="form-group">
							<input type="number" name="tipocliente_montodesc" value="<?php echo $this->input->post('tipocliente_montodesc'); ?>" class="form-control" id="tipocliente_montodesc" />
						</div>
					</div>
				</div>
			</div>
          	<div class="box-footer">
            	<button type="submit" class="btn btn-success">
            		<i class="fa fa-check"></i> Guardar
            	</button>
          	</div>
            <?php echo form_close(); ?>
      	</div>
    </div>
</div>