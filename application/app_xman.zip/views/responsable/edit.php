<div class="row">
    <div class="col-md-12">
      	<div class="box box-info">
            <div class="box-header with-border">
              	<h3 class="box-title">Editar Responsable</h3>
            </div>
			<?php echo form_open('responsable/edit/'.$responsable['responsable_id']); ?>
			<div class="box-body">
				<div class="row clearfix">
					<div class="col-md-6">
						<label for="responsable_nombres" class="control-label"><span class="text-danger">*</span>Nombres</label>
						<div class="form-group">
							<input type="text" name="responsable_nombres" value="<?php echo ($this->input->post('responsable_nombres') ? $this->input->post('responsable_nombres') : $responsable['responsable_nombres']); ?>" class="form-control" id="responsable_nombres" required />
							<span class="text-danger"><?php echo form_error('responsable_nombres');?></span>
						</div>
					</div>
					<div class="col-md-6">
						<label for="responsable_apellidos" class="control-label"><span class="text-danger">*</span>Apellidos</label>
						<div class="form-group">
							<input type="text" name="responsable_apellidos" value="<?php echo ($this->input->post('responsable_apellidos') ? $this->input->post('responsable_apellidos') : $responsable['responsable_apellidos']); ?>" class="form-control" id="responsable_apellidos" required />
							<span class="text-danger"><?php echo form_error('responsable_apellidos');?></span>
						</div>
					</div>
					<div class="col-md-6">
						<label for="responsable_ci" class="control-label">Ci</label>
						<div class="form-group">
							<input type="text" name="responsable_ci" value="<?php echo ($this->input->post('responsable_ci') ? $this->input->post('responsable_ci') : $responsable['responsable_ci']); ?>" class="form-control" id="responsable_ci" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="responsable_cargo" class="control-label">Cargo</label>
						<div class="form-group">
							<input type="text" name="responsable_cargo" value="<?php echo ($this->input->post('responsable_cargo') ? $this->input->post('responsable_cargo') : $responsable['responsable_cargo']); ?>" class="form-control" id="responsable_cargo" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="responsable_telefono" class="control-label">Teléfono</label>
						<div class="form-group">
							<input type="text" name="responsable_telefono" value="<?php echo ($this->input->post('responsable_telefono') ? $this->input->post('responsable_telefono') : $responsable['responsable_telefono']); ?>" class="form-control" id="responsable_telefono" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="responsable_direccion" class="control-label">Dirección</label>
						<div class="form-group">
							<input type="text" name="responsable_direccion" value="<?php echo ($this->input->post('responsable_direccion') ? $this->input->post('responsable_direccion') : $responsable['responsable_direccion']); ?>" class="form-control" id="responsable_direccion" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="responsable_imagen" class="control-label">Imagen</label>
						<div class="form-group">
							<input type="text" name="responsable_imagen" value="<?php echo ($this->input->post('responsable_imagen') ? $this->input->post('responsable_imagen') : $responsable['responsable_imagen']); ?>" class="form-control" id="responsable_imagen" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="responsable_latitud" class="control-label">Latitud</label>
						<div class="form-group">
							<input type="number" name="responsable_latitud" value="<?php echo ($this->input->post('responsable_latitud') ? $this->input->post('responsable_latitud') : $responsable['responsable_latitud']); ?>" class="form-control" id="responsable_latitud" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="responsable_longitud" class="control-label">Longitud</label>
						<div class="form-group">
							<input type="number" name="responsable_longitud" value="<?php echo ($this->input->post('responsable_longitud') ? $this->input->post('responsable_longitud') : $responsable['responsable_longitud']); ?>" class="form-control" id="responsable_longitud" />
						</div>
					</div>
				</div>
			</div>
			<div class="box-footer">
            	<button type="submit" class="btn btn-success">
					<i class="fa fa-check"></i> Guardar
				</button>
	        </div>				
			<?php echo form_close(); ?>
		</div>
    </div>
</div>