<!----------------------------- script buscador --------------------------------------->
<script src="<?php echo base_url('resources/js/jquery-2.2.3.min.js'); ?>" type="text/javascript"></script>
<script type="text/javascript">
        $(document).ready(function () {
            (function ($) {
                $('#filtrar').keyup(function () {
                    var rex = new RegExp($(this).val(), 'i');
                    $('.buscar tr').hide();
                    $('.buscar tr').filter(function () {
                        return rex.test($(this).text());
                    }).show();
                })
            }(jQuery));
        });
</script>   
<!----------------------------- fin script buscador --------------------------------------->
<!------------------ ESTILO DE LAS TABLAS ----------------->
<link href="<?php echo base_url('resources/css/mitabla.css'); ?>" rel="stylesheet">
<!-------------------------------------------------------->

<div class="box-header">
                <h3 class="box-title">Compras Completadas</h3>
            	<div class="box-tools">
                    <a href="<?php echo site_url('compra/anula'); ?>" class="btn btn-warning btn-sm">Modificar Compra</a> 
                    <a href="<?php echo site_url('compra/crearcompra'); ?>" class="btn btn-success btn-sm">+ Añadir Compra</a>
                </div>
            </div>
<div class="row">
    <div class="col-md-12">
        <!--------------------- parametro de buscador --------------------->
                  <div class="input-group"> <span class="input-group-addon">Buscar</span>
                    <input id="filtrar" type="text" class="form-control" placeholder="Ingrese el codigo, fecha, glosa">
                  </div>
            <!--------------------- fin parametro de buscador --------------------->
        <div class="box">
            
            <div class="box-body table-responsive" >
                <table class="table table-striped table-condensed" id="mitabla">
                    <tr>
                                          <th>N</th>
                        <th>Proveedor</th>
<!--                        <th>Sub <br>Total</th>
                        <th>Desc.</th>-->
                        <th>Total</th>
                        <th>Fecha<br>Hora</th>
                        <th>Estado</th>
                        <th></th>
                    </tr>
                    <tbody class="buscar">
                    <?php $cont = 0;
                    $total = 0;
                          foreach($compra as $c){;
                          $cont = $cont+1;
                          $hoy = date('Y-m-d');
                          
                         if ($c['compra_fecha'] == $hoy) {
                            $subto = $c['compra_totalfinal'];
                            $total = $total + $subto;
                    ?>
                    <tr>
						<td><?php echo $cont ?></td>
                        <!--<td><?php //echo $p['compra_id']; ?></td>-->
                        <td><font size="3"><b><?php echo $c['proveedor_nombre']; ?></b></font> <br>
                        <span class="btn-info btn-xs"><?php echo $c['tipotrans_nombre']; ?></span>
                        
                                            
                        
                        <td align="right" ><?php echo "Sub Total: ".number_format($c['compra_subtotal'],'2','.',','); ?><br>
                                          <?php echo "Desc.: ".number_format($c['compra_descuento'],'2','.',','); ?><br>
                                          <?php echo "Desc.Global: ".number_format($c['compra_descglobal'],'2','.',','); ?><br>  
                                          <font size="3"><b><?php echo number_format($c['compra_totalfinal'],'2','.',','); ?></b></font></td>
                        
                        <td><?php echo date('d/m/Y',strtotime($c['compra_fecha'])) ; ?><br>
                            <?php echo $c['compra_hora']; ?></td>
                        <td><?php echo $c['estado_descripcion']; ?></td>
                       	<td>
                            <!--<a href="<?php echo site_url('compra/edit/'.$c['compra_id']); ?>" class="btn btn-info btn-xs"><span class="fa fa-pencil"></span></a>-->
                            <a href="<?php echo site_url('compra/pdf/'.$c['compra_id']); ?>" target="_blank" class="btn btn-success btn-xs"><span class="fa fa-print"></span></a>  
                            <!--<a href="<?php echo site_url('compra/remove/'.$c['compra_id']); ?>" class="btn btn-danger btn-xs"><span class="fa fa-trash"></span></a>-->
                        </td>
                    </tr>
                    
                    <?php } } ?>

                    <tr>
                    <td></td>    
                    <td align="right"><b>TOTAL</b></td> 
                    <td align="right"><font size="4"><b><?php echo number_format($total,'2','.',','); ?></b></font></td>
                    <td></td>    
                    <td></td>
                    <td></td>
                    </tr>
                    <?php ?>
                </table>
                
            </div>
            <div class="pull-right">
                    <?php echo $this->pagination->create_links(); ?>                    
                </div>                
        </div>
    </div>
</div>

<div class="row">
    <div class="col-md-12">
        <!--------------------- parametro de buscador --------------------->
<!--                  <div class="input-group"> <span class="input-group-addon">Buscar</span>
                    <input id="filtrar" type="text" class="form-control" placeholder="Ingrese el proveedor, fecha, total">
                  </div>-->
            <!--------------------- fin parametro de buscador --------------------->
              <h4 class="box-title"> Compras sin Proveedor asignado</h4>
        <div class="box">
          
                <div class="box-body table-responsive">
                <table class="table table-striped table-condensed" id="mitabla">
                    <tr>
                        <th>Num.</th>
                        <th>Id</th>
                        <th>Proveedor</th>
                        <th>Fecha</th>
                        <th>Subtotal</th>
                        <th>Descuento</th>
                        <th>Total</th>
                        <th>Glosa</th>
                        <th>Estado</th>
                        <th> </th>
                    </tr>
                    <tbody class="buscar1">
                    <?php $cont = 0;
                    $bandera = 0;
                          foreach($comprasn as $psn){;
                                 $cont = $cont+1; ?>
                    <tr>
                        <td><?php echo $cont ?></td>
                        <td><?php echo $psn['compra_id']; ?></td>
                        <td><?php echo $psn['proveedor_id']; ?></td>
                        <td><?php echo $psn['compra_fecha']; ?></td>
                        <td><?php echo $psn['compra_subtotal']; ?></td>
                        <td><?php echo $psn['compra_descuento']; ?></td>  
                        <td><?php echo $psn['compra_total']; ?></td>
                        <td><?php echo $psn['compra_glosa']; ?></td>
                        <td><?php echo $psn['estado_descripcion']; ?></td>
                        <td>
                            <a href="<?php echo site_url('compra/edit/'.$psn['compra_id'].'/'.$bandera); ?>" class="btn btn-info btn-xs"><span class="fa fa-pencil"></span></a>
                            <a href="<?php echo site_url('compra/edito/'.$psn['compra_id']); ?>" class="btn btn-success btn-xs"><span class="fa fa-asterisk"></span></a>  
                            <a href="<?php echo site_url('compra/remove/'.$psn['compra_id']); ?>" class="btn btn-danger btn-xs"><span class="fa fa-trash"></span></a>
                        </td>
                    </tr>
                    <?php } ?>
                </table>
                                
            </div>
<!--            <div class="pull-right">
                    <?php echo $this->pagination->create_links(); ?>                    
            </div>-->
        </div>
    </div>
</div>
