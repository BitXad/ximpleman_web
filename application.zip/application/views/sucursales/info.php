<h1>Inventario</h1>
<span class="small">Productos</span>
<?php print_r($inventario)?>
