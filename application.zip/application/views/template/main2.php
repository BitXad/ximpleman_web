<!-- Main content -->
<section class="content">
    <?php
        echo $main;
    ?>
</section>
<!-- /.content -->