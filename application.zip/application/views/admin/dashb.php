        <!-- Main content -->
        <section class="content">
            <?php
                echo $web;
            ?>
        </section>
        <!-- /.content -->